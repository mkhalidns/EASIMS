# EASIMS
Exam Answer Sheets Inventory Management System

Clean Architecture + Repository Pattern

Projects:
- EASIMS.Domain
- EASIMS.Application
- EASIMS.Infrastructure
- EASIMS.Web

Roles:
- Admin
- User

Areas:
- Admin
- User

Permissions:
- Inventory.View
- Inventory.Add
- Inventory.Update
- Inventory.Delete
- Inventory.Return

Structure only; no business implementation.
